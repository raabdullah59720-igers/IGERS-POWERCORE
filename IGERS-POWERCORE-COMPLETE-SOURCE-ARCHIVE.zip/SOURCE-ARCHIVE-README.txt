IGERS POWERCORE source preservation archive

Original source tree file count: 243. The active dependency closure is available directly at the outer package root; unused/legacy files and original `index.html`/`sw.js` are stored here. The exact original nested IGERS-BD-01-App-Package.zip binary is preserved byte-for-byte, and its 83 payload members have SHA-256 records in LEGACY-APP-PACKAGE-MANIFEST.tsv. Do not extract this archive over the deployed repository root.
