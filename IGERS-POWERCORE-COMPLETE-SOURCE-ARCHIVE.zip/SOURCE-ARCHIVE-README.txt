IGERS POWERCORE source preservation archive

This companion archive retains inactive/legacy source files, documents, historic assets, and original source snapshots. It also contains the exact original IGERS-BD-01-App-Package.zip binary byte-for-byte; its 83 internal payload members have been SHA-256 inventoried in LEGACY-APP-PACKAGE-MANIFEST.tsv.

Do NOT extract this archive or the nested app package over the live deployment root. The deployable integrated app files are already at the root of the outer ZIP. The preservation archive exists so the root package can remain below the 98-entry upload limit without discarding source material.

The separate source ZIP uploaded for the project had 243 outer source files; all of their contents are preserved either in the outer deployable root or in this archive, with original index.html and sw.js retained under ORIGINAL-BASELINE/.
