package com.igers.powercore

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Native host for the IGERS web interface. WireGuard profiles stay in memory only. */
class MainActivity : AppCompatActivity() {
    companion object {
        private const val APP_HOST = "appassets.androidplatform.net"
        private const val MAX_CONFIG_BYTES = 64 * 1024
    }

    private lateinit var webView: WebView
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private var pendingConfig: Config? = null

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val cfg = pendingConfig
        pendingConfig = null
        if (result.resultCode == Activity.RESULT_OK && cfg != null) {
            startTunnel(cfg)
        } else {
            emitStatus("permission_denied", "Android VPN permission was not granted. No tunnel was started.")
        }
    }

    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var webMessageBridgeSupported = false
    private val profilePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val callback = fileChooserCallback
        fileChooserCallback = null
        if (uri == null) callback?.onReceiveValue(null) else callback?.onReceiveValue(arrayOf(uri))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(false)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                settings.safeBrowsingEnabled = true
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    return request?.url?.let { assetLoader.shouldInterceptRequest(it) }
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (!webMessageBridgeSupported && url == "https://$APP_HOST/assets/www/index.html") {
                        view?.evaluateJavascript("window.IGERSVpnNativeResult && window.IGERSVpnNativeResult('unsupported','Update Android System WebView to enable the secure native VPN bridge.');", null)
                    }
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    if (uri.scheme == "https" && uri.host == APP_HOST) return false
                    // Keep external embedded feeds isolated in their own frames; open top-level links externally.
                    if (!request.isForMainFrame) return false
                    if (uri.scheme == "https" || uri.scheme == "http") {
                        return try {
                            startActivity(Intent(Intent.ACTION_VIEW, uri))
                            true
                        } catch (_: Exception) { true }
                    }
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = filePathCallback
                    profilePicker.launch(arrayOf("*/*"))
                    return true
                }
            }
        }
        setContentView(webView)
        (application as IgersApplication).statusListener = { state, message -> emitStatus(state, message) }

        // Origin-allowlisted messaging is used instead of addJavascriptInterface.
        // External iframes do not receive the native object; messages must originate in the main frame.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            webMessageBridgeSupported = true
            WebViewCompat.addWebMessageListener(
                webView,
                "IGERSVpnBridge",
                setOf("https://$APP_HOST")
            ) { _, message: WebMessageCompat, sourceOrigin, isMainFrame, replyProxy: JavaScriptReplyProxy ->
                if (!isMainFrame || sourceOrigin.scheme != "https" || sourceOrigin.host != APP_HOST || sourceOrigin.port != -1) {
                    replyProxy.postMessage("{\"ok\":false,\"error\":\"origin_rejected\"}")
                    return@addWebMessageListener
                }
                try {
                    val messageData = message.data ?: "{}"
                    if (messageData.length > MAX_CONFIG_BYTES + 2048) {
                        replyProxy.postMessage("{\"ok\":false,\"error\":\"message_too_large\"}")
                        return@addWebMessageListener
                    }
                    val envelope = JSONObject(messageData)
                    val action = envelope.optString("action")
                    val payload = envelope.optJSONObject("payload") ?: JSONObject()
                    when (action) {
                        "connect" -> requestConnect(payload.optString("config"))
                        "disconnect" -> requestDisconnect()
                        "status" -> requestStatus()
                        else -> emitStatus("error", "Unsupported native VPN action.")
                    }
                    replyProxy.postMessage("{\"ok\":true,\"accepted\":true}")
                } catch (e: Exception) {
                    emitStatus("error", "Native VPN request could not be parsed.")
                    replyProxy.postMessage("{\"ok\":false,\"error\":\"invalid_request\"}")
                }
            }
        }

        webView.loadUrl("https://$APP_HOST/assets/www/index.html")
    }

    private fun requestConnect(raw: String) {
        val byteLength = raw.toByteArray(StandardCharsets.UTF_8).size
        if (raw.isBlank() || byteLength > MAX_CONFIG_BYTES) {
            emitStatus("profile_error", "Missing profile or profile exceeds 64 KB. Import a valid WireGuard .conf file first.")
            return
        }
        executor.execute {
            try {
                val parsed = Config.parse(ByteArrayInputStream(raw.toByteArray(StandardCharsets.UTF_8)))
                if (parsed.getPeers().isEmpty()) throw IllegalArgumentException("Profile has no [Peer] section.")
                runOnUiThread {
                    pendingConfig = parsed
                    AlertDialog.Builder(this)
                        .setTitle("Connect IGERS VPN?")
                        .setMessage("A VPN profile can route some or all device traffic through its configured endpoint. Continue only if you trust the profile provider. IGERS does not supply a VPN server or credentials.")
                        .setNegativeButton("Cancel") { _, _ ->
                            pendingConfig = null
                            emitStatus("down", "VPN connection cancelled by the user. No tunnel was started.")
                        }
                        .setPositiveButton("Continue") { _, _ ->
                            val consentIntent = VpnService.prepare(this)
                            if (consentIntent != null) {
                                emitStatus("permission_required", "Approve Android's system VPN permission prompt. IGERS will then start the selected WireGuard profile.")
                                vpnPermissionLauncher.launch(consentIntent)
                            } else {
                                pendingConfig = null
                                startTunnel(parsed)
                            }
                        }
                        .setOnCancelListener {
                            pendingConfig = null
                            emitStatus("down", "VPN connection cancelled. No tunnel was started.")
                        }
                        .show()
                }
            } catch (e: Exception) {
                emitStatus("profile_error", "WireGuard rejected this profile: ${safeMessage(e)}")
            }
        }
    }

    private fun startTunnel(config: Config) {
        emitStatus("connecting", "Starting the native WireGuard tunnel. Waiting for the Android tunnel engine.")
        executor.execute {
            try {
                val state = (application as IgersApplication).backend.setState((application as IgersApplication).tunnel, Tunnel.State.UP, config)
                if (state == Tunnel.State.UP) {
                    emitStatus("up", "Android reports the WireGuard tunnel interface is active. The profile has not been saved by IGERS. Check peer handshake and traffic for end-to-end connectivity.")
                } else {
                    emitStatus("error", "WireGuard did not bring the tunnel interface up.")
                }
            } catch (e: Exception) {
                emitStatus("error", "WireGuard connect failed: ${safeMessage(e)}. Check profile keys, endpoint, network and Android VPN permission.")
            }
        }
    }

    private fun requestDisconnect() {
        executor.execute {
            try {
                (application as IgersApplication).backend.setState((application as IgersApplication).tunnel, Tunnel.State.DOWN, null)
                emitStatus("down", "Disconnect request completed. The system tunnel is stopped.")
            } catch (e: Exception) {
                emitStatus("error", "WireGuard disconnect failed: ${safeMessage(e)}")
            }
        }
    }

    private fun requestStatus() {
        executor.execute {
            try {
                val state = (application as IgersApplication).backend.getState((application as IgersApplication).tunnel)
                if (state == Tunnel.State.UP) emitStatus("up", "Native WireGuard interface is up. Peer handshake is a separate check.")
                else emitStatus("down", "No active IGERS WireGuard tunnel in this app process.")
            } catch (e: Exception) {
                emitStatus("error", "Could not query WireGuard state: ${safeMessage(e)}")
            }
        }
    }

    private fun emitStatus(state: String, message: String) {
        if (!::webView.isInitialized) return
        val safeState = JSONObject.quote(state)
        val safeMessage = JSONObject.quote(message.take(700))
        runOnUiThread {
            if (!isFinishing && ::webView.isInitialized) {
                webView.evaluateJavascript(
                    "window.IGERSVpnNativeResult && window.IGERSVpnNativeResult($safeState,$safeMessage);",
                    null
                )
            }
        }
    }

    private fun safeMessage(error: Throwable): String {
        return (error.message ?: error.javaClass.simpleName).replace(Regex("[\\r\\n]+"), " ").take(220)
    }

    override fun onDestroy() {
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        executor.shutdown()
        (application as? IgersApplication)?.statusListener = null
        super.onDestroy()
    }
}
