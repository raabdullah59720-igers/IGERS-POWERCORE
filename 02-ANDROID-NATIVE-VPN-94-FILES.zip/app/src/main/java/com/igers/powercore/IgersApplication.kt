package com.igers.powercore

import android.app.Application
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel

/** Process-wide tunnel owner so re-opening the activity can query/stop the same tunnel. */
class IgersApplication : Application() {
    val backend: GoBackend by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        GoBackend(applicationContext)
    }

    @Volatile var statusListener: ((String, String) -> Unit)? = null

    val tunnel: Tunnel = object : Tunnel {
        override fun getName(): String = "IGERS_PowerCore"
        override fun onStateChange(newState: Tunnel.State) {
            if (newState == Tunnel.State.UP) {
                notifyStatus("up", "Android has established the WireGuard tunnel interface. Verify recent peer handshake and traffic before assuming full internet access.")
            } else {
                notifyStatus("down", "WireGuard tunnel is stopped.")
            }
        }
    }

    fun notifyStatus(state: String, message: String) {
        statusListener?.invoke(state, message)
    }
}
