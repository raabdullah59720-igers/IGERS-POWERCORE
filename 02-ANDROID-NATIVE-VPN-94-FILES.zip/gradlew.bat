@echo off
setlocal
set "GRADLE_VERSION=8.13"
set "BOOT_ROOT=%USERPROFILE%\.gradle\igers-bootstrap"
set "GRADLE_HOME=%BOOT_ROOT%\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%BOOT_ROOT%" mkdir "%BOOT_ROOT%"
  set "GRADLE_ZIP=%BOOT_ROOT%\gradle-%GRADLE_VERSION%-bin.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%BOOT_ROOT%\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -LiteralPath '%BOOT_ROOT%\gradle-%GRADLE_VERSION%-bin.zip' -DestinationPath '%BOOT_ROOT%' -Force; Remove-Item '%BOOT_ROOT%\gradle-%GRADLE_VERSION%-bin.zip' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
