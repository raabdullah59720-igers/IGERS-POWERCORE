# IGERS PowerCore — Android Native VPN Host

This is an Android Studio project that bundles the current IGERS web app into a WebView and adds a native WireGuard tunnel backend. The website's panel exposes **Import .conf**, **Connect VPN**, and **Disconnect** controls. The native code uses Android's VPN permission flow and the official WireGuard tunnel library.

## Build on Windows
1. Install Android Studio and Android SDK Platform 36.
2. Open a terminal in this folder and run `gradlew.bat assembleDebug` (the included bootstrap script downloads Gradle 8.13 on first run).
3. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.
4. Install it on a real Android device. Open the VPN panel, import a trusted WireGuard `.conf`, tap Connect VPN, confirm the native security dialog, and accept Android's VPN permission prompt if shown.

## বাংলা
এই native Android project-এ IGERS-এর ওয়েব অ্যাপ এবং WireGuard tunnel backend একসঙ্গে আছে। `gradlew.bat assembleDebug` চালিয়ে Debug APK তৈরি করা যায়। APK ইনস্টল করে VPN panel-এ বিশ্বস্ত `.conf` profile import করো, তারপর **Connect VPN** চাপো এবং Android-এর VPN permission prompt অনুমোদন করো। **Disconnect** একই tunnel বন্ধ করবে।

## Security and limitations
- Profiles are validated by the WireGuard parser and kept in memory only by the IGERS UI/native connector; IGERS does not write profile content to local storage.
- The user must confirm the native connection dialog; the Android system VPN consent prompt must also be accepted when Android requests it.
- The app does not bundle a VPN server, endpoint, private key, or free internet bandwidth. A valid profile from a trusted provider or a server you control is required.
- “Tunnel interface active” does not by itself prove a successful peer handshake or working internet. Verify recent handshake and traffic in the provider's server/client tools.
- The native bridge uses origin-allowlisted WebMessageListener (not `addJavascriptInterface`) and checks the trusted main-frame origin.
- Source package only; no compiled/signed APK is included. This environment did not have Android SDK/Gradle, so compilation and physical-device tests remain outstanding.

## License notice
This project depends on the official WireGuard Android tunnel library, which is distributed under Apache-2.0. The library dependency is declared in `app/build.gradle.kts`; its license/copyright remains with WireGuard.

## Build via GitHub Actions
Upload the contents of this Android project to its own GitHub repository (project files at repository root). Open **Actions → Build IGERS Android VPN APK → Run workflow**. After a successful run, download the `IGERS-PowerCore-Direct-VPN-debug-APK` artifact. This workflow builds a debug APK, not a signed production release.
