# IGERS PowerCore — Direct VPN Desktop Connector (Windows)

## বাংলা
এই Electron host-এ IGERS-এর পুরো ওয়েব অ্যাপ bundled আছে। VPN panel থেকে একটি বিশ্বস্ত WireGuard `.conf` profile import করে **Connect VPN** চাপলে official WireGuard for Windows-এর tunnel service চালু করার চেষ্টা করবে এবং Windows administrator/UAC permission চাইবে। **Disconnect** একই IGERS-managed tunnel service বন্ধ করে।

### প্রয়োজনীয়তা
- Windows desktop/laptop.
- Official WireGuard for Windows ইনস্টল করা থাকতে হবে.
- VPN provider অথবা নিজের server থেকে valid WireGuard `.conf` profile লাগবে.
- Connect/Disconnect-এর সময় Windows administrator consent/UAC প্রয়োজন হতে পারে.
- এটি source code; package-এ compiled `.exe` বা signed installer নেই. Windows-এ installer বানাতে `npm run dist:win` চালানো যায়.

### চালানো
1. Node.js-এর supported LTS version ইনস্টল করো.
2. এই folder-এ terminal খুলে `npm install` চালাও.
3. `npm start` চালাও. Installer তৈরি করতে `npm run dist:win` চালাও (Windows build machine প্রয়োজন).
4. VPN panel → Import `.conf` → Connect VPN. UAC consent চাইলে যাচাই করে অনুমতি দাও.
5. Disconnect দিয়ে শুধু এই connector-এর তৈরি tunnel বন্ধ করো.

`.conf` ফাইলে private key থাকে। অ্যাপ অস্থায়ী staging file থেকে official WireGuard Manager-এর protected Configurations folder-এ profile দেয়; manager profile-টি DPAPI-encrypted `.conf.dpapi` হিসেবে রাখে এবং plaintext copy মুছে দেয়। Tunnel disconnect করলে service ও এই IGERS-managed protected profile দুটোই সরানোর চেষ্টা করা হয়। Config browser storage-এ রাখা হয় না। Trusted provider ছাড়া config import কোরো না.

## English / limitations
- This native bridge directly manages WireGuard for Windows only; Linux/macOS are not supported in this build.
- A running Windows tunnel service does not by itself prove a successful peer handshake or working internet. Verify latest handshake/traffic in WireGuard.
- No VPN server, endpoint credentials, private key, free internet service, or subscription is bundled. The Windows connector uses WireGuard Manager’s documented DPAPI profile protection; it has not yet been run on an actual Windows host in this environment.
- This bridge is intentionally not available in the static GitHub Pages website. The web panel still appears there but correctly reports that OS-level direct VPN is unavailable without the native host.
- Do not turn off OS security prompts or import profiles from unknown sources.
- Native desktop behavior was syntax-checked but not run on Windows in this build environment.
