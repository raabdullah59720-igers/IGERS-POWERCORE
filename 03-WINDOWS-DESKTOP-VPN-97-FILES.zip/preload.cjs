'use strict';
const { contextBridge, ipcRenderer } = require('electron');

// Only narrow IPC methods are exposed; renderer code receives no Node.js API.
contextBridge.exposeInMainWorld('IGERSVpnBridge', Object.freeze({
  platform: 'Windows desktop native connector',
  connectConfig: (configText) => ipcRenderer.invoke('vpn:connect', configText),
  disconnect: () => ipcRenderer.invoke('vpn:disconnect'),
  getStatus: () => ipcRenderer.invoke('vpn:status'),
  onStatus: (callback) => {
    if (typeof callback !== 'function') return () => {};
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('vpn:status-event', listener);
    return () => ipcRenderer.removeListener('vpn:status-event', listener);
  }
}));
