'use strict';
const { app, BrowserWindow, ipcMain, shell } = require('electron');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn, spawnSync } = require('node:child_process');
const crypto = require('node:crypto');

const WEB_ROOT = path.resolve(__dirname, 'web');
const STATE_FILE = () => path.join(app.getPath('userData'), 'active-igers-tunnel.json');
let mainWindow = null;
let localServer = null;
let localOrigin = '';
let activeTunnel = null;

function emitStatus(state, message) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('vpn:status-event', { state, message });
}
function readActiveTunnel() {
  try {
    const saved = JSON.parse(fs.readFileSync(STATE_FILE(), 'utf8'));
    if (typeof saved.name === 'string' && /^IGERS_[A-Z0-9_]+$/.test(saved.name)) return saved.name;
  } catch (_) {}
  return null;
}
function saveActiveTunnel(name) {
  fs.mkdirSync(path.dirname(STATE_FILE()), { recursive: true });
  fs.writeFileSync(STATE_FILE(), JSON.stringify({ name, updatedAt: new Date().toISOString() }), { mode: 0o600 });
}
function clearActiveTunnel() {
  try { fs.unlinkSync(STATE_FILE()); } catch (_) {}
  activeTunnel = null;
}
function findWireGuardExe() {
  const roots = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.LOCALAPPDATA].filter(Boolean);
  for (const base of roots) {
    const candidate = path.join(base, 'WireGuard', 'wireguard.exe');
    if (fs.existsSync(candidate)) return candidate;
  }
  try {
    const result = spawnSync('where.exe', ['wireguard.exe'], { encoding: 'utf8', windowsHide: true, timeout: 5000 });
    if (result.status === 0) {
      const candidate = String(result.stdout).split(/\r?\n/).map(x => x.trim()).find(x => x && fs.existsSync(x));
      if (candidate) return candidate;
    }
  } catch (_) {}
  return null;
}
function psQuote(value) { return "'" + String(value).replace(/'/g, "''") + "'"; }
function runElevatedPowerShell(scriptText) {
  return new Promise((resolve, reject) => {
    // Windows PowerShell -EncodedCommand expects Base64 of UTF-16LE. The payload is
    // encoded so config paths / profile contents cannot break the bootstrap quoting.
    const encoded = Buffer.from(scriptText, 'utf16le').toString('base64');
    const bootstrap = "$ErrorActionPreference='Stop'; $b='" + encoded + "'; $p=Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-EncodedCommand',$b) -Verb RunAs -Wait -PassThru; if ($null -eq $p.ExitCode) { exit 1 } else { exit $p.ExitCode }";
    const child = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', bootstrap], {
      windowsHide: false, stdio: ['ignore', 'pipe', 'pipe']
    });
    let stdout = '', stderr = '', finished = false;
    const timer = setTimeout(() => {
      if (!finished) { child.kill(); reject(new Error('Timed out waiting for Windows elevation / WireGuard.')); }
    }, 120000);
    child.stdout.on('data', chunk => { stdout += chunk.toString(); });
    child.stderr.on('data', chunk => { stderr += chunk.toString(); });
    child.once('error', error => { finished = true; clearTimeout(timer); reject(error); });
    child.once('close', code => {
      finished = true; clearTimeout(timer);
      if (code === 0) resolve({ stdout, stderr });
      else reject(new Error((stderr || stdout || 'Windows elevated operation failed or UAC was cancelled.').trim().slice(0, 900)));
    });
  });
}
function elevatedLiteral(value) {
  return "'" + String(value).replace(/'/g, "''") + "'";
}
function protectedProfilePath(wireguardExe, tunnelName) {
  return path.join(path.dirname(wireguardExe), 'Data', 'Configurations', tunnelName + '.conf.dpapi');
}
function validateProfile(raw) {
  if (typeof raw !== 'string' || Buffer.byteLength(raw, 'utf8') > 65536) return 'Profile missing or larger than 64 KB.';
  if (!/^\s*\[Interface\]\s*$/im.test(raw) || !/^\s*\[Peer\]\s*$/im.test(raw)) return 'Profile must contain [Interface] and [Peer] sections.';
  if (!/^\s*PrivateKey\s*=\s*\S+/im.test(raw) || !/^\s*PublicKey\s*=\s*\S+/im.test(raw) || !/^\s*AllowedIPs\s*=\s*\S+/im.test(raw)) return 'Required WireGuard keys or AllowedIPs are missing.';
  return null;
}
async function connectConfig(raw) {
  const validation = validateProfile(raw);
  if (validation) return { ok: false, state: 'profile_error', message: validation };
  if (process.platform !== 'win32') return { ok: false, state: 'unsupported', message: 'This desktop companion currently controls the official WireGuard for Windows service. On this OS use the WireGuard native client; Linux/macOS control is not included in this build.' };
  if (activeTunnel) {
    const current = await getVpnStatus();
    if (current.state === 'service_running') return { ok: false, state: 'error', message: 'An IGERS-managed tunnel is already running. Disconnect it first before switching profiles.' };
    if (current.state === 'service_stopped') return { ok: false, state: 'service_stopped', message: 'An earlier IGERS profile remains in WireGuard’s protected store. Press Disconnect once to clean it up before importing another profile.' };
  }
  const wireguardExe = findWireGuardExe();
  if (!wireguardExe) return { ok: false, state: 'error', message: 'WireGuard for Windows was not found. Install the official client first, then reopen IGERS.' };

  const tunnelName = 'IGERS_' + Date.now().toString(36).toUpperCase() + '_' + crypto.randomBytes(2).toString('hex').toUpperCase();
  const sourceProfilePath = path.join(app.getPath('temp'), tunnelName + '.conf');
  const protectedPath = protectedProfilePath(wireguardExe, tunnelName);
  const wireguardLit = elevatedLiteral(wireguardExe);
  const sourceLit = elevatedLiteral(sourceProfilePath);
  const nameLit = elevatedLiteral(tunnelName);
  const configDirLit = elevatedLiteral(path.dirname(protectedPath));
  const protectedLit = elevatedLiteral(protectedPath);
  try {
    // The plaintext staging file is created only briefly; the official manager service
    // moves it to a DPAPI-encrypted, SYSTEM-protected profile in Program Files.
    fs.writeFileSync(sourceProfilePath, raw, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
    const script = `
$ErrorActionPreference = 'Stop'
$wg = ${wireguardLit}
$source = ${sourceLit}
$name = ${nameLit}
$configDir = ${configDirLit}
$plain = Join-Path $configDir ($name + '.conf')
$protected = ${protectedLit}
try {
  if (-not (Test-Path -LiteralPath $wg)) { throw 'WireGuard executable not found.' }
  New-Item -ItemType Directory -Path $configDir -Force | Out-Null
  $manager = Get-Service -Name 'WireGuardManager' -ErrorAction SilentlyContinue
  if (-not $manager) {
    & $wg /installmanagerservice
    if ($LASTEXITCODE -ne 0) { throw 'Could not install the WireGuard manager service.' }
  }
  $manager = Get-Service -Name 'WireGuardManager' -ErrorAction SilentlyContinue
  if (-not $manager) { throw 'WireGuard manager service is unavailable.' }
  if ($manager.Status -ne 'Running') {
    Start-Service -Name 'WireGuardManager'
    (Get-Service -Name 'WireGuardManager').WaitForStatus('Running', [TimeSpan]::FromSeconds(15))
  }
  if ((Test-Path -LiteralPath $plain) -or (Test-Path -LiteralPath $protected)) { throw 'A profile with this name already exists; retry the connection.' }
  Copy-Item -LiteralPath $source -Destination $plain
  $deadline = (Get-Date).AddSeconds(25)
  while ((Test-Path -LiteralPath $plain) -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 250 }
  if (-not (Test-Path -LiteralPath $protected)) { throw 'WireGuard manager did not create the encrypted .conf.dpapi profile; tunnel was not installed.' }
  & $wg /installtunnelservice $protected
  if ($LASTEXITCODE -ne 0) { throw 'WireGuard could not start the tunnel service.' }
  exit 0
} catch {
  $serviceName = 'WireGuardTunnel$' + $name
  $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
  if ($service) { & $wg /uninstalltunnelservice $name 2>$null; Start-Sleep -Milliseconds 500 }
  if (Test-Path -LiteralPath $plain) { Remove-Item -LiteralPath $plain -Force -ErrorAction SilentlyContinue }
  if (Test-Path -LiteralPath $protected) { Remove-Item -LiteralPath $protected -Force -ErrorAction SilentlyContinue }
  [Console]::Error.WriteLine($_.Exception.Message)
  exit 1
}`;
    emitStatus('connecting', 'Requesting Windows administrator approval. WireGuard will protect the profile before installing its tunnel service.');
    await runElevatedPowerShell(script);
    activeTunnel = tunnelName;
    saveActiveTunnel(tunnelName);
    emitStatus('service_running', 'Windows reports that the IGERS WireGuard tunnel service started with a protected DPAPI profile. Peer handshake and working internet still need verification.');
    return { ok: true, state: 'service_running', message: 'WireGuard tunnel service started and the profile is stored encrypted by WireGuard for Windows. Check the latest peer handshake and traffic to confirm server connectivity.' };
  } catch (error) {
    const message = error && error.message ? error.message : 'WireGuard did not start.';
    emitStatus('error', message);
    return { ok: false, state: 'error', message };
  } finally {
    // WireGuard has copied/encrypted the profile for an installed service; remove staging plaintext.
    try { fs.unlinkSync(sourceProfilePath); } catch (_) {}
  }
}
async function disconnectTunnel() {
  if (process.platform !== 'win32') return { ok: false, state: 'unsupported', message: 'Use the native WireGuard client on this OS; this connector only controls WireGuard for Windows.' };
  const name = activeTunnel || readActiveTunnel();
  if (!name) return { ok: true, state: 'down', message: 'No active IGERS-managed tunnel is recorded.' };
  const wireguardExe = findWireGuardExe();
  if (!wireguardExe) return { ok: false, state: 'error', message: 'WireGuard for Windows was not found; cannot issue a disconnect command.' };
  const wireguardLit = elevatedLiteral(wireguardExe);
  const nameLit = elevatedLiteral(name);
  const configPath = protectedProfilePath(wireguardExe, name);
  const configLit = elevatedLiteral(configPath);
  const configDirLit = elevatedLiteral(path.dirname(configPath));
  try {
    const script = `
$ErrorActionPreference = 'Stop'
$wg = ${wireguardLit}
$name = ${nameLit}
$configDir = ${configDirLit}
$protected = ${configLit}
$plain = Join-Path $configDir ($name + '.conf')
$serviceName = 'WireGuardTunnel$' + $name
try {
  $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
  if ($service) {
    & $wg /uninstalltunnelservice $name
    if ($LASTEXITCODE -ne 0) { throw 'WireGuard could not stop/remove the tunnel service.' }
    Start-Sleep -Milliseconds 500
  }
  if (Test-Path -LiteralPath $protected) { Remove-Item -LiteralPath $protected -Force }
  if (Test-Path -LiteralPath $plain) { Remove-Item -LiteralPath $plain -Force }
  exit 0
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  exit 1
}`;
    await runElevatedPowerShell(script);
    clearActiveTunnel();
    emitStatus('down', 'IGERS-managed WireGuard tunnel is disconnected. The protected profile was removed from the WireGuard store.');
    return { ok: true, state: 'down', message: 'WireGuard tunnel stopped; protected IGERS profile removed.' };
  } catch (error) {
    const message = error && error.message ? error.message : 'Could not stop the WireGuard service.';
    emitStatus('error', message);
    return { ok: false, state: 'error', message };
  }
}
async function getVpnStatus() {
  if (process.platform !== 'win32') return { ok: false, state: 'unsupported', message: 'Direct status integration is Windows-only in this desktop build.' };
  const name = activeTunnel || readActiveTunnel();
  if (!name) return { ok: true, state: 'down', message: 'No IGERS-managed WireGuard tunnel is recorded as active.' };
  const ps = "$s=Get-Service -Name " + psQuote('WireGuardTunnel$' + name) + " -ErrorAction SilentlyContinue; if ($s) { Write-Output $s.Status } else { Write-Output 'NotFound' }";
  const result = spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], { encoding: 'utf8', windowsHide: true, timeout: 10000 });
  const state = String(result.stdout || '').trim();
  if (result.status === 0 && state === 'Running') return { ok: true, state: 'service_running', message: 'Windows reports the IGERS WireGuard tunnel service is running. A running service does not prove peer handshake or internet access.' };
  if (state === 'Stopped' || state === 'NotFound') return { ok: true, state: 'service_stopped', message: 'Windows reports the IGERS tunnel service is stopped. Press Disconnect to remove the protected profile and clear its record.' };
  return { ok: false, state: 'unknown', message: 'Could not verify the WireGuard tunnel service state. Check the WireGuard application / Windows services.' };
}

const mime = { '.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.geojson':'application/geo+json','.pdf':'application/pdf','.woff2':'font/woff2','.woff':'font/woff' };
function startLocalServer() {
  return new Promise((resolve, reject) => {
    localServer = http.createServer((req, res) => {
      let pathname;
      try { pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname); } catch (_) { res.writeHead(400); res.end('Bad URL'); return; }
      if (pathname === '/') pathname = '/index.html';
      const target = path.resolve(WEB_ROOT, '.' + pathname);
      if (target !== WEB_ROOT && !target.startsWith(WEB_ROOT + path.sep)) { res.writeHead(403); res.end('Forbidden'); return; }
      fs.readFile(target, (error, data) => {
        if (error) { res.writeHead(error.code === 'ENOENT' ? 404 : 500); res.end(error.code === 'ENOENT' ? 'Not found' : 'Read error'); return; }
        res.writeHead(200, { 'Content-Type': mime[path.extname(target).toLowerCase()] || 'application/octet-stream', 'X-Content-Type-Options':'nosniff', 'Cache-Control':'no-store' });
        res.end(data);
      });
    });
    localServer.once('error', reject);
    localServer.listen(0, '127.0.0.1', () => {
      localOrigin = `http://127.0.0.1:${localServer.address().port}`;
      resolve(localOrigin);
    });
  });
}
async function createWindow() {
  await startLocalServer();
  mainWindow = new BrowserWindow({
    width: 1440, height: 960, minWidth: 360, minHeight: 600,
    backgroundColor: '#050b10', show: false,
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), nodeIntegration: false, contextIsolation: true, sandbox: true, webSecurity: true, allowRunningInsecureContent: false }
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (url !== localOrigin + '/' && url !== localOrigin + '/index.html' && !url.startsWith(localOrigin + '/')) {
      event.preventDefault();
      if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    }
  });
  mainWindow.once('ready-to-show', () => mainWindow.show());
  await mainWindow.loadURL(localOrigin + '/index.html');
}

app.whenReady().then(async () => {
  activeTunnel = readActiveTunnel();
  ipcMain.handle('vpn:connect', (_event, configText) => connectConfig(configText));
  ipcMain.handle('vpn:disconnect', () => disconnectTunnel());
  ipcMain.handle('vpn:status', () => getVpnStatus());
  await createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
}).catch(error => { console.error('IGERS desktop startup failed:', error); app.quit(); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => { if (localServer) localServer.close(); });
